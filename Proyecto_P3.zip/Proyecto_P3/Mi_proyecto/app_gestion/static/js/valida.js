function validar()
{
     nombre = document.formulario_ingreso.txt_nombre.value;
     rut = document.formulario_ingreso.txt_rut.value;
     appaterno = document.formulario_ingreso.txt_appaterno.value;
     apmaterno = document.formulario_ingreso.txt_apmaterno.value;
     edad = document.formulario_ingreso.txt_edad.value;
     
    

    if(nombre.length<=2)
    {
        alert("Nombre debe tener mas de 2 caracteres");
        document.formulario_ingreso.txt_nombre.focus();
        return false;
    }
    if (rut<9 || rut>10 || rut.indexOf('-')<0 || rut.indexOf('.')>0)
    {
        alert("El rut debe tener entre 9 y 10 caracteres, debe contener un guión y no debe contener puntos");
        document.formulario_ingreso.txt_rut.focus();
        return false;
    }
    if (appaterno.length <3)
    {
        alert("El apellido paterno debe contener al menos 3 caracteres");
        document.formulario_ingreso.txt_appaterno.focus();
        return false;
    }
    if (apmaterno.length <3)
    {
        alert("El apellido materno debe contener al menos 3 caracteres");
        document.formulario_ingreso.txt_apmaterno.focus();
        return false;
    }
    if (edad <= 1)
    {
        alert("Debe ingresar la edad");
        document.formulario_ingreso.txt_edad.focus();
        return false;
    }
    
    
    document.formulario_ingreso.action= "/ingreso_persona/"
    document.formulario_ingreso.submit() = true
    alert("Persona ingresada Correctamente");
}
